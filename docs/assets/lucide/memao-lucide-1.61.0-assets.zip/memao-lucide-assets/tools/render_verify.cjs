const fs=require('fs'),path=require('path'),sharp=require('sharp');
const root=path.resolve(__dirname,'..');
async function main(){
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
 for(const mode of ['light','dark'])await sharp(path.join(root,'previews',`icons-${mode}.svg`)).png().toFile(path.join(root,'previews',`icons-${mode}.png`));
 const differences=[];
 for(const icon of manifest.icons){
  const svg=fs.readFileSync(path.join(root,icon.svg),'utf8');
  const xml=fs.readFileSync(path.join(root,icon.android),'utf8');
  const paths=[...xml.matchAll(/<path ([^>]+)\/>/g)].map(m=>{const attrs=Object.fromEntries([...m[1].matchAll(/android:(\w+)="([^"]+)"/g)].map(a=>[a[1],a[2]]));return `<path d="${attrs.pathData}" fill="${attrs.fillColor==='#00000000'?'none':'black'}" stroke="black" stroke-width="${attrs.strokeWidth}" stroke-linecap="${attrs.strokeLineCap}" stroke-linejoin="${attrs.strokeLineJoin}"/>`}).join('');
  const reconstructed=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">${paths}</svg>`;
  for(const size of [20,24,32]){
   const a=await sharp(Buffer.from(svg)).resize(size,size).ensureAlpha().raw().toBuffer();
   const b=await sharp(Buffer.from(reconstructed)).resize(size,size).ensureAlpha().raw().toBuffer();
   let sum=0,max=0,count=0;
   for(let i=3;i<a.length;i+=4){const d=Math.abs(a[i]-b[i]);sum+=d;max=Math.max(max,d);if(d>0)count++}
   differences.push({name:icon.name,size,alpha_mean_absolute_error:sum/(size*size),alpha_max_error:max,changed_pixels:count});
  }
 }
 const result={icons:manifest.count,comparisons:differences.length,note:'SVG-to-path geometric comparison using the same rasterizer. Not an Android on-device rendering test.',max_mean_alpha_error:Math.max(...differences.map(x=>x.alpha_mean_absolute_error)),differences};
 fs.writeFileSync(path.join(root,'verification.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({icons:result.icons,comparisons:result.comparisons,max_mean_alpha_error:result.max_mean_alpha_error,worst:differences.sort((a,b)=>b.alpha_mean_absolute_error-a.alpha_mean_absolute_error).slice(0,4)}));
 if(result.max_mean_alpha_error>2)throw Error('Conversion requires visual review: mean alpha error > 2 / 255');
}
main().catch(e=>{console.error(e);process.exit(1)});
