"""Generate Memao's pinned Lucide assets. Python standard library only."""
from pathlib import Path
import concurrent.futures, hashlib, html, json, re, sys, urllib.request, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.61.0'
COMMIT = 'c29c276f16590cf017126671535ad8c792be64d8'
BASE = f'https://raw.githubusercontent.com/lucide-icons/lucide/{COMMIT}/'
ROWS = [
('NOTES','notebook-text','笔记'),('DRAFT','file-pen-line','草稿'),('ARCHIVE','archive','归档'),('SETTINGS','settings','设置'),
('PLUS','plus','新建'),('BACK','arrow-left','返回'),('SEARCH','search','搜索'),('CLOSE','x','关闭／清除'),('DOWN','chevron-down','展开'),
('EDIT','square-pen','编辑'),('DELETE','trash','删除'),('IMAGE','image','图片'),('AUDIO','audio-lines','音频'),('PASTE','clipboard-paste','粘贴图片'),
('TAG','tag','标签'),('EYE','eye','预览／显示'),('CHECK','check','确认'),('REFRESH','refresh-cw','刷新'),('LOCK','lock-keyhole','私密'),
('COPY','copy','复制'),('MORE','ellipsis','更多'),('PLAY','play','播放'),('PAUSE','pause','暂停'),
('UNARCHIVE','archive-restore','取消归档'),('NEXT','chevron-right','进入下一级'),('EYE_OFF','eye-off','隐藏 Token'),('FILE','file','通用文件'),
('HEADING','heading-1','标题'),('BOLD','bold','粗体'),('ITALIC','italic','斜体'),('LIST','list','无序列表'),('ORDERED_LIST','list-ordered','有序列表'),
('QUOTE','quote','引用'),('LINK','link','链接'),('TASK_LIST','list-todo','待办列表'),('UNCHECKED','square','未完成待办'),('CHECKED','square-check','已完成待办'),
('PUBLIC','globe','公开'),('PROTECTED','shield','受保护')]

def fetch(path):
    data=urllib.request.urlopen(BASE+path,timeout=30).read()
    dst=ROOT/('source-svg/'+Path(path).name if path.startswith('icons/') else path)
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)

def num(value):return format(float(value),'.12g')

def path_data(e):
    tag=e.tag.split('}')[-1]; a=e.attrib
    if tag=='path': return a['d']
    if tag=='line': return f'M{a["x1"]},{a["y1"]} L{a["x2"]},{a["y2"]}'
    if tag in ('polyline','polygon'):
        pts=re.findall(r'-?\d*\.?\d+(?:[eE][-+]?\d+)?',a['points'])
        assert len(pts)%2==0
        return 'M'+' L'.join(','.join(pts[i:i+2]) for i in range(0,len(pts),2))+(' Z' if tag=='polygon' else '')
    if tag in ('circle','ellipse'):
        x=float(a['cx']);y=float(a['cy']);rx=float(a.get('r',a.get('rx')));ry=float(a.get('r',a.get('ry')))
        return f'M{num(x-rx)},{num(y)} A{num(rx)},{num(ry)} 0 1,0 {num(x+rx)},{num(y)} A{num(rx)},{num(ry)} 0 1,0 {num(x-rx)},{num(y)} Z'
    if tag=='rect':
        x=float(a.get('x',0));y=float(a.get('y',0));w=float(a['width']);h=float(a['height'])
        rx=min(float(a.get('rx',a.get('ry',0))),w/2);ry=min(float(a.get('ry',a.get('rx',0))),h/2)
        if not rx or not ry:return f'M{x},{y} h{w} v{h} h{-w} Z'
        return f'M{x+rx},{y} H{x+w-rx} A{rx},{ry} 0 0,1 {x+w},{y+ry} V{y+h-ry} A{rx},{ry} 0 0,1 {x+w-rx},{y+h} H{x+rx} A{rx},{ry} 0 0,1 {x},{y+h-ry} V{y+ry} A{rx},{ry} 0 0,1 {x+rx},{y} Z'
    raise ValueError('Unsupported SVG element: '+tag)

def convert(svg):
    root=ET.fromstring(svg)
    assert root.attrib['viewBox']=='0 0 24 24'
    assert root.attrib.get('fill')=='none'
    assert root.attrib.get('stroke-width')=='2'
    assert root.attrib.get('stroke-linecap')=='round' and root.attrib.get('stroke-linejoin')=='round'
    paths=[]
    for e in root:
        assert not any(k in e.attrib for k in ('transform','style','stroke','stroke-width')), e.attrib
        fill=e.attrib.get('fill','none')
        assert fill in ('none','currentColor')
        paths.append((path_data(e),'#FF000000' if fill=='currentColor' else '#00000000'))
    xml='<?xml version="1.0" encoding="utf-8"?>\n<!-- Lucide '+VERSION+'; '+COMMIT+'; see LICENSE. -->\n'
    xml+='<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n'
    for p,fill in paths:xml+='  <path android:pathData="'+html.escape(p,quote=True)+'" android:fillColor="'+fill+'" android:strokeColor="#FF000000" android:strokeWidth="2" android:strokeLineCap="round" android:strokeLineJoin="round" />\n'
    xml+='</vector>\n'
    return xml

def inner_svg(svg):return re.sub(r'</svg>\s*$','',re.sub(r'^.*?<svg[^>]*>','',svg,flags=re.S)).strip()

def make_sheet(items,dark):
    bg,fg,muted,line=('#17191c','#f4f5f6','#9da3ac','#34383e') if dark else ('#ffffff','#22252a','#7a8089','#e8eaed')
    width=1440;height=1500
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="1440" height="1500" fill="{bg}"/><g font-family="PingFang SC,Arial,sans-serif" fill="{fg}">',
      '<text x="48" y="65" font-size="30" font-weight="600">Memao / Lucide</text>',
      f'<text x="48" y="102" font-size="16" fill="{muted}">39 icons · v{VERSION} · 20 / 24 / 32 px · '+('深色' if dark else '浅色')+'</text>']
    for i,item in enumerate(items):
        x=48+(i%6)*224;y=145+(i//6)*182
        out.append(f'<g transform="translate({x},{y})"><line x1="0" y1="0" x2="200" y2="0" stroke="{line}"/>')
        for size,dx in [(20,4),(24,59),(32,118)]:
            out.append(f'<svg x="{dx}" y="{40-size/2}" width="{size}" height="{size}" viewBox="0 0 24 24" color="{fg}" fill="none" stroke="{fg}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{item["inner"]}</svg>')
        out.append(f'<text y="89" font-size="16">{item["label"]}</text><text y="116" font-size="12" fill="{muted}">{item["name"]}</text><text y="141" font-size="11" fill="{muted}">{item["semantic"]}</text></g>')
    out.append(f'<text x="48" y="1470" font-size="13" fill="{muted}">Official SVG geometry · Android XML included · Application integration pending</text></g></svg>')
    return ''.join(out)

def gallery(items):
    data=json.dumps(items,ensure_ascii=False).replace('</','<\\/')
    return '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Memao Lucide 图标素材</title><style>
*{box-sizing:border-box}body{margin:0;background:#fafafa;color:#24272c;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;--card:#fff;--line:#e5e7eb;--muted:#727985}body.dark{background:#17191c;color:#f4f5f6;--card:#202328;--line:#363b43;--muted:#a5acb6}.wrap{max-width:1240px;margin:auto;padding:36px 28px}h1{font-size:30px;margin:0 0 10px}p{color:var(--muted);line-height:1.7}.controls{display:flex;gap:12px;flex-wrap:wrap;margin:26px 0}button,input,select{color:inherit;background:var(--card);border:1px solid var(--line);padding:12px 16px;border-radius:8px;font:inherit;min-height:48px}button{cursor:pointer}input{flex:1;min-width:200px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px}.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:20px;min-height:225px}.icons{height:58px;display:flex;align-items:center;gap:26px}.card h2{font-size:16px;margin:12px 0 8px}.name,.meta{font-size:12px;color:var(--muted)}.actions{display:flex;gap:8px;margin-top:15px}.actions button{font-size:12px;padding:8px 12px}.tip{font-size:13px;margin-top:24px}.sizes{font-size:12px;color:var(--muted);margin:10px 0}svg{flex-shrink:0}.statebar{display:flex;gap:28px;align-items:center;padding:20px 0;flex-wrap:wrap}.statebar>span{display:flex;gap:9px;align-items:center}.disabled{opacity:.38}.danger{color:#c23d35}
</style><div class="wrap"><h1>Memao / Lucide</h1><p>完整应用内图标素材 · 39 个官方矢量图标 · Lucide 1.61.0<br>20 / 24 / 32 是预览像素尺寸；Android 接入时对应 dp。当前为素材预览，尚未接入 APP。</p><div class="controls"><input id="q" placeholder="按用途、语义或文件名搜索" aria-label="搜索图标"><select id="size" aria-label="预览尺寸"><option value="all">20 / 24 / 32</option>'''+''.join(f'<option value="{n}">{n} px</option>' for n in [20,24,32])+'''</select><button id="theme">切换深色</button></div><div class="statebar" id="states"></div><div id="count" class="sizes"></div><div class="grid" id="grid"></div><p class="tip">SVG 和 XML 可逐个下载；完整素材已包含在此素材包中。许可证、来源清单与重建工具随包保存。大屏只改变布局，不放大图标。</p></div><script>
const items='''+data+''';
const q=document.getElementById('q'),size=document.getElementById('size'),grid=document.getElementById('grid');
function icon(it,s){return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${it.inner}</svg>`}
function save(name,text,mime){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function render(){grid.innerHTML='';let visible=items.filter(i=>(i.label+' '+i.name+' '+i.semantic).toLowerCase().includes(q.value.toLowerCase()));document.getElementById('count').textContent=`${visible.length} / ${items.length} 个图标`;for(const it of visible){const el=document.createElement('article');el.className='card';el.innerHTML=`<div class="icons">${(size.value==='all'?[20,24,32]:[+size.value]).map(s=>icon(it,s)).join('')}</div><h2>${it.label}</h2><div class="name">${it.name}</div><p class="meta">${it.semantic}</p><div class="actions"><button>下载 SVG</button><button>下载 XML</button></div>`;const bs=el.querySelectorAll('button');bs[0].onclick=()=>save(it.name+'.svg',it.svg,'image/svg+xml');bs[1].onclick=()=>save('ic_lucide_'+it.name.replaceAll('-','_')+'.xml',it.xml,'application/xml');grid.appendChild(el)}}
q.oninput=render;size.onchange=render;document.getElementById('theme').onclick=()=>{const dark=document.body.classList.toggle('dark');document.getElementById('theme').textContent=dark?'切换浅色':'切换深色'};
document.getElementById('states').innerHTML='<span>'+icon(items[0],24)+'普通</span><span style="font-weight:600">'+icon(items[1],24)+'选中</span><span class="disabled">'+icon(items[4],24)+'禁用</span><span class="danger">'+icon(items[10],24)+'危险操作</span>';render();</script></html>'''

def main():
    for name in ['source-svg','android-drawable','previews']: (ROOT/name).mkdir(exist_ok=True)
    if '--fetch' in sys.argv:
        paths=['icons/'+name+'.svg' for _,name,_ in ROWS]+['LICENSE']
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(fetch,paths))
    items=[];manifest=[]
    for semantic,name,label in ROWS:
        src=ROOT/'source-svg'/f'{name}.svg';svg=src.read_text();xml=convert(svg)
        dst=ROOT/'android-drawable'/('ic_lucide_'+name.replace('-','_')+'.xml');dst.write_text(xml)
        items.append(dict(semantic=semantic,name=name,label=label,svg=svg,inner=inner_svg(svg),xml=xml))
        manifest.append(dict(semantic=semantic,name=name,label=label,svg=str(src.relative_to(ROOT)),android=str(dst.relative_to(ROOT)),source_url=BASE+'icons/'+name+'.svg',svg_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),android_sha256=hashlib.sha256(dst.read_bytes()).hexdigest()))
    info=dict(library='Lucide',version=VERSION,commit=COMMIT,release_url=f'https://github.com/lucide-icons/lucide/releases/tag/{VERSION}',count=len(items),baseline_commit='bb81088613964f3093f283eacf1b533eb886efe3',icons=manifest)
    (ROOT/'manifest.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
    for dark in [False,True]:(ROOT/'previews'/('icons-dark.svg' if dark else 'icons-light.svg')).write_text(make_sheet(items,dark))
    (ROOT/'gallery.html').write_text(gallery(items))
    print(json.dumps(dict(count=len(items),version=VERSION,commit=COMMIT,html_bytes=(ROOT/'gallery.html').stat().st_size)))

if __name__=='__main__':main()
